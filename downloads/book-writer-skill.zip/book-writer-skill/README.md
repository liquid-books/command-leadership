# Book Writer Skill Bundle

A complete AgentSkill toolkit for creating, illustrating, and publishing books as
[MyST Markdown](https://mystmd.org) sites deployed to GitHub Pages.

This bundle contains two skills that work together:

| Skill | What it does |
|---|---|
| **`book-writer/`** | Scaffolds book projects, writes/validates chapters, generates covers and chapter images |
| **`github-books/`** | Creates the GitHub repo, pushes content, enables Pages, reports deploy status |

---

## What You Get

```
book-writer-skill/
├── README.md                      ← you are here
├── book-writer/
│   ├── SKILL.md                   ← main instructions for the agent
│   ├── references/
│   │   └── myst-syntax-guide.md   ← MyST directive reference (READ THIS)
│   └── scripts/
│       ├── scaffold-book.js       ← create a new book project
│       ├── generate-cover.js      ← 3D cover via image-to-image
│       ├── generate-image.js      ← chapter illustrations
│       ├── build-book.js          ← local HTML build
│       ├── check-fences.js        ← validate MyST directive nesting
│       ├── validate-chapter.js    ← chapter QA
│       ├── update-index-toc.js    ← regenerate landing page TOC
│       └── update-registry.js     ← optional Google Sheets tracking
├── github-books/
│   ├── SKILL.md
│   └── scripts/
│       └── github-api.js          ← repo create / push / Pages
└── templates/
    └── cover-physics-template.png ← 3D book mockup used for covers
```

---

## Installation

Drop both skill folders into your agent's skills directory:

```bash
unzip book-writer-skill.zip
cp -r book-writer-skill/book-writer   ~/openclaw/skills/
cp -r book-writer-skill/github-books  ~/openclaw/skills/
```

Then tell your agent: *"read skills/book-writer/SKILL.md"*.

---

## Required Credentials

**No API keys are bundled in this zip.** Every script reads its credentials from
disk at runtime. You must create these two files yourself.

### 1. OpenRouter — for cover and chapter image generation

Get a key at <https://openrouter.ai/keys>, then:

```bash
mkdir -p ~/.openclaw
printf '%s' 'sk-or-v1-YOUR-KEY-HERE' > ~/.openclaw/openrouter-api-key
chmod 600 ~/.openclaw/openrouter-api-key
```

Used by `generate-image.js` and `generate-cover.js`. Models, in fallback order:

1. `google/gemini-3-pro-image-preview` (Nano Banana Pro)
2. `google/gemini-3.1-flash-image-preview` (Nano Banana 2)

> **Note:** free-tier Google API keys generally have **zero quota** for these
> image models. Route through OpenRouter with credit on the account.

### 2. GitHub — for repo creation and Pages deploy

Create a fine-grained PAT at <https://github.com/settings/tokens?type=beta> with
**Administration: Read/Write**, **Contents: Read/Write**, **Pages: Read/Write**
on the target account or org. Then:

```bash
printf '%s' 'github_pat_YOUR-TOKEN-HERE' > ~/.openclaw/github-token
chmod 600 ~/.openclaw/github-token
```

### Changing the credential paths

The paths are constants at the top of each script:

```js
// book-writer/scripts/generate-image.js
const OPENROUTER_KEY_PATH = '/home/node/.openclaw/openrouter-api-key';

// github-books/scripts/github-api.js
const TOKEN_PATH = '/home/node/.openclaw/github-token';
```

Edit those two lines if your home directory differs.

### Also configure the books directory

Several scripts assume books live at `/home/node/openclaw/books`:

```js
const BOOKS_DIR = '/home/node/openclaw/books';
```

Found in `scaffold-book.js`, `build-book.js`, and `generate-cover.js`. Update to match your setup.

### GitHub account

`github-books/SKILL.md` references the `liquid-books` account throughout. Replace
it with your own username or org.

---

## Prerequisites

- **Node.js 18+** (20+ recommended)
- **`mystmd`** — installed on demand via `npx -y mystmd`, no global install needed
- **ImageMagick** (optional) — `convert` is used to normalize covers to PNG24

---

## Quickstart

```bash
# 1. Scaffold
node book-writer/scripts/scaffold-book.js my-first-book "My First Book" "Author Name"

# 2. Generate a cover (image-to-image off the physics template)
node book-writer/scripts/generate-cover.js my-first-book "dark navy, minimal, gold serif title"

# 3. Write chapters into books/my-first-book/chapters/*.md
#    then validate directive nesting BEFORE pushing
node book-writer/scripts/check-fences.js my-first-book

# 4. Publish
node github-books/scripts/github-api.js create-repo my-first-book "My First Book"
node github-books/scripts/github-api.js push /path/to/books/my-first-book my-first-book "Initial commit"
node github-books/scripts/github-api.js enable-pages my-first-book
```

Live in 2–4 minutes at `https://<account>.github.io/my-first-book`.

---

## Two Gotchas That Will Bite You

These are the two failure modes that cost the most time. Both are now handled by
the scripts, but know them anyway.

### 1. `BASE_URL` must be set or the site renders unstyled

GitHub Pages serves project sites from a subpath (`/repo-name/`). Without
`BASE_URL`, MyST emits asset paths at the domain root, every CSS/JS file 404s,
and you get raw unstyled HTML plus a MyST warning banner.

The generated `.github/workflows/deploy.yml` must contain:

```yaml
on:
  push:
    branches: [main]
env:
  BASE_URL: /${{ github.event.repository.name }}
```

Verify after any deploy — paths must start with `/<repo-name>/`:

```bash
curl -s https://<account>.github.io/<repo>/ | grep -o 'href="[^"]*\.css"'
```

> MyST content-hashes images to `/build/cover-<hash>.png`. The original
> `/images/cover.png` path is **not** served. That 404 is expected, not a bug.

### 2. MyST directives nest by fence length

A nested directive's closing fence must be **shorter** than its parent's. Same
length silently closes the parent, dumping the rest of your page into a literal
code block.

```markdown
::::{grid} 2          ← 4 colons (outer)

:::{grid-item-card} A  ← 3 colons (inner)
Body text.
:::

:::{grid-item-card} B
Body text.
:::

::::                   ← 4 colons closes the grid
```

Run `check-fences.js` before every push. To confirm on a live page — a healthy
landing page has **zero** `<pre>` blocks unless you intentionally included code:

```bash
curl -s https://<account>.github.io/<repo>/ | grep -c '<pre'
```

---

## Optional: Google Sheets Registry

`update-registry.js` tracks books and chapters in a Google Sheet. It needs
Google OAuth credentials wired separately and is **entirely optional** — skip it
and everything else works. If you use it, create your own sheet and store its ID
at `books/.registry-sheet-id`.

---

## License

Provided as-is for personal use.
