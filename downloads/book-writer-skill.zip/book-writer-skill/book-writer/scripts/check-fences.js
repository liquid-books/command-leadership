#!/usr/bin/env node
/**
 * check-fences.js — catch MyST nested-directive fence bugs before they ship.
 *
 * MyST closes a directive at the FIRST close marker of matching length. A nested
 * directive using the same fence length as its parent silently truncates the parent,
 * and everything after it renders as a literal code block.
 *
 * Usage:
 *   node check-fences.js <file.md> [more.md ...]
 *
 * Exit codes:
 *   0 = all files clean
 *   1 = at least one defect found
 */

const fs = require('fs');

const OPEN = /^(:{3,})\{([a-zA-Z0-9:_-]+)\}/;
const CLOSE = /^(:{3,})\s*$/;
const CODEFENCE = /^\s*(```|~~~)/;

function checkFile(path) {
  let lines;
  try {
    lines = fs.readFileSync(path, 'utf8').split('\n');
  } catch (e) {
    console.error(`  ERROR  cannot read ${path}: ${e.message}`);
    return 1;
  }

  const problems = [];
  const stack = [];
  let inCode = false;

  lines.forEach((line, idx) => {
    const lineNo = idx + 1;

    if (CODEFENCE.test(line)) {
      inCode = !inCode;
      return;
    }
    if (inCode) return;

    const open = line.match(OPEN);
    if (open) {
      const len = open[1].length;
      const name = open[2];
      if (stack.length) {
        const parent = stack[stack.length - 1];
        if (parent.len <= len) {
          problems.push(
            `L${lineNo}: {${name}} uses ${len} colons inside {${parent.name}} ` +
            `(L${parent.line}, ${parent.len} colons) — parent must be longer`
          );
        }
      }
      stack.push({ len, name, line: lineNo });
      return;
    }

    const close = line.match(CLOSE);
    if (close && stack.length) stack.pop();
  });

  stack.forEach((s) => {
    problems.push(`L${s.line}: {${s.name}} is never closed`);
  });

  if (problems.length) {
    console.log(`\x1b[31mFAIL\x1b[0m  ${path}`);
    problems.forEach((p) => console.log(`      ${p}`));
    return 1;
  }
  console.log(`\x1b[32mOK\x1b[0m    ${path}`);
  return 0;
}

const files = process.argv.slice(2);
if (!files.length) {
  console.error('usage: node check-fences.js <file.md> [more.md ...]');
  process.exit(2);
}

const failed = files.map(checkFile).reduce((a, b) => a + b, 0);
if (failed) {
  console.log(`\n${failed} file(s) with fence defects. Fix before committing.`);
  process.exit(1);
}
console.log(`\nAll ${files.length} file(s) clean.`);
process.exit(0);
