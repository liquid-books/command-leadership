#!/usr/bin/env node
/**
 * generate-cover.js
 * Generates a book cover using NanoBanana Pro and saves it to images/cover.png
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const slug = process.argv[2];
const title = process.argv[3];
const author = process.argv[4] || "Dr. Ernesto Lee";

if (!slug || !title) {
  console.error('Usage: node generate-cover.js <slug> "<title>" ["author"]');
  process.exit(1);
}

const bookDir = path.join('/home/node/openclaw/books', slug);
const outputPath = path.join(bookDir, 'images/cover.png');

if (!fs.existsSync(path.join(bookDir, 'images'))) {
  fs.mkdirSync(path.join(bookDir, 'images'), { recursive: true });
}

const prompt = `A realistic 3D rendered hardcover textbook standing upright, slightly angled to show both the front cover and the spine. The book is titled "${title}" in bold white sans-serif font on the front cover. Author name "${author}" at the bottom of the cover in clean white text. Deep navy blue cover with vibrant orange geometric accents and a glowing abstract neural network pattern. The spine shows the abbreviated title and author. Photorealistic book mockup, studio lighting, white background, professional publishing quality, slight shadow beneath the book.`;

console.log(`Generating cover for: ${title}`);

try {
  const cmd = `node /home/node/openclaw/skills/book-writer/scripts/generate-image.js "${outputPath}" "${prompt.replace(/"/g, '\\"')}" --aspect-ratio portrait`;
  const result = execSync(cmd, { encoding: 'utf8' });
  console.log(result);
  
  // Update index.md to include the cover
  const indexPath = path.join(bookDir, 'index.md');
  if (fs.existsSync(indexPath)) {
    let indexContent = fs.readFileSync(indexPath, 'utf8');
    if (!indexContent.includes('cover.png')) {
      const coverHeader = `:::{figure} ./images/cover.png\n:width: 300px\n:align: center\n:::\n\n`;
      indexContent = indexContent.replace(/# .*\n/, (match) => match + coverHeader);
      fs.writeFileSync(indexPath, indexContent);
      console.log('Updated index.md with cover image.');
    }
  }
  
} catch (e) {
  console.error('Failed to generate cover:', e.message);
  process.exit(1);
}
