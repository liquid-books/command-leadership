#!/usr/bin/env node
/**
 * Generate a single image for book chapters.
 *
 * Model priority (default):
 *   1. Nano Banana Pro  — google/gemini-3-pro-image-preview  via OpenRouter
 *   2. Nano Banana 2    — google/gemini-3.1-flash-image-preview via OpenRouter
 *   3. FLUX.1 Pro       — fal.ai (final fallback)
 *
 * Usage:
 *   node generate-image.js <output-path> "<prompt>" [--aspect-ratio landscape|portrait|square] [--model flash|pro|flux]
 *
 * Exit codes:
 *   0 = success (prints JSON with path, size, model used)
 *   1 = failure (prints JSON with error)
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const OPENROUTER_KEY_PATH = '/home/node/.openclaw/openrouter-api-key';

const OR_MODELS = {
  pro:   'google/gemini-3-pro-image-preview',
  flash: 'google/gemini-3.1-flash-image-preview',
};

const MIN_SIZE = 50 * 1024;
const MAX_RETRIES = 2;
const RETRY_DELAY = 3000;

const ASPECT_RATIO_HINTS = {
  landscape: 'wide landscape orientation (16:9)',
  portrait:  'tall portrait orientation (9:16)',
  square:    'square orientation (1:1)',
  book:      'portrait orientation with a 4:5 canvas ratio (slightly taller than wide, NOT elongated)',
};

function log(msg) { process.stderr.write(msg + '\n'); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function saveBase64(base64, outPath) {
  const dir = path.dirname(outPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(outPath, Buffer.from(base64, 'base64'));
}

function downloadFile(url, outPath) {
  return new Promise((resolve, reject) => {
    const dir = path.dirname(outPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const file = fs.createWriteStream(outPath);
    https.get(url, res => {
      if (res.statusCode !== 200) { reject(new Error(`Download failed: ${res.statusCode}`)); return; }
      res.pipe(file);
      file.on('finish', () => { file.close(); resolve(); });
      file.on('error', err => { if (fs.existsSync(outPath)) fs.unlinkSync(outPath); reject(err); });
    }).on('error', err => { if (fs.existsSync(outPath)) fs.unlinkSync(outPath); reject(err); });
  });
}

// --- OpenRouter (Nano Banana Pro / Flash) ---
async function generateWithOpenRouter(modelKey, prompt, outPath) {
  const apiKey = fs.readFileSync(OPENROUTER_KEY_PATH, 'utf8').trim();
  const model = OR_MODELS[modelKey];

  const payload = JSON.stringify({
    model,
    messages: [{ role: 'user', content: prompt }]
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'openrouter.ai',
      path: '/api/v1/chat/completions',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'HTTP-Referer': 'https://openclaw.ai',
        'X-Title': 'OpenClaw Book Writer'
      },
      timeout: 120000
    }, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', async () => {
        if (res.statusCode !== 200) { reject(new Error(`OpenRouter ${res.statusCode}: ${d.slice(0, 300)}`)); return; }
        try {
          const j = JSON.parse(d);
          const msg = j.choices?.[0]?.message;
          if (!msg) { reject(new Error('No message in OpenRouter response')); return; }

          // OpenRouter returns Gemini images in message.images[], not message.content
          const images = msg.images;
          if (images && images.length > 0) {
            const dataUrl = images[0]?.image_url?.url || '';
            if (dataUrl.startsWith('data:image')) {
              saveBase64(dataUrl.split(',')[1], outPath);
              resolve(); return;
            } else if (dataUrl.startsWith('http')) {
              log(`Downloading image...`);
              await downloadFile(dataUrl, outPath);
              resolve(); return;
            }
          }

          // Fallback: scan content array
          const content = msg.content;
          if (Array.isArray(content)) {
            for (const part of content) {
              const src = part.image_url?.url || '';
              if (src.startsWith('data:image')) { saveBase64(src.split(',')[1], outPath); resolve(); return; }
              if (src.startsWith('http')) { await downloadFile(src, outPath); resolve(); return; }
            }
          }

          reject(new Error('No image found in OpenRouter response'));
        } catch (e) { reject(e); }
      });
    });
    req.on('error', e => reject(e));
    req.on('timeout', () => { req.destroy(); reject(new Error('OpenRouter timeout')); });
    req.write(payload); req.end();
  });
}

// --- Main generation with fallback chain ---
async function generateImage(prompt, outPath, aspectRatioKey, forceModel) {
  const arHint = ASPECT_RATIO_HINTS[aspectRatioKey] || ASPECT_RATIO_HINTS.landscape;
  const fullPrompt = `${prompt}. Use ${arHint}.`;

    const chain = forceModel === 'flash' ? ['flash'] : ['pro', 'flash']; // Pro first, Flash fallback. No FLUX.

  for (const modelKey of chain) {
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        log(`[${modelKey.toUpperCase()} attempt ${attempt}/${MAX_RETRIES}] Generating image...`);
        await generateWithOpenRouter(modelKey, fullPrompt, outPath);

        const stats = fs.statSync(outPath);
        if (stats.size < MIN_SIZE) throw new Error(`Image too small (${stats.size} bytes)`);

        log(`✓ Saved to ${outPath} (${Math.round(stats.size / 1024)}KB) via ${modelKey}`);
        return { success: true, path: outPath, size: stats.size, model: modelKey === 'flux' ? 'flux-pro' : OR_MODELS[modelKey], provider: modelKey === 'flux' ? 'fal.ai' : 'openrouter' };
      } catch (err) {
        log(`✗ ${modelKey} attempt ${attempt} failed: ${err.message}`);
        if (attempt < MAX_RETRIES) await sleep(RETRY_DELAY);
      }
    }
    log(`→ ${modelKey} exhausted, trying next...`);
  }
  throw new Error('All models failed.');
}

// --- CLI ---
async function main() {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    log('Usage: node generate-image.js <output-path> "<prompt>" [--aspect-ratio landscape|portrait|square] [--model pro|flash|flux]');
    process.exit(1);
  }
  const outPath = args[0];
  const prompt = args[1];
  let aspectRatioKey = 'landscape';
  const arIdx = args.indexOf('--aspect-ratio');
  if (arIdx !== -1 && args[arIdx + 1]) aspectRatioKey = args[arIdx + 1].toLowerCase();
  let forceModel = null;
  const mIdx = args.indexOf('--model');
  if (mIdx !== -1 && args[mIdx + 1]) forceModel = args[mIdx + 1].toLowerCase();

  try {
    const result = await generateImage(prompt, outPath, aspectRatioKey, forceModel);
    console.log(JSON.stringify(result, null, 2));
    process.exit(0);
  } catch (err) {
    console.log(JSON.stringify({ success: false, error: err.message, path: outPath }, null, 2));
    process.exit(1);
  }
}

main();
