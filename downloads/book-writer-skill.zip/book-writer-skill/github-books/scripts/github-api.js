#!/usr/bin/env node
/**
 * GitHub API CLI for book repository management
 * Usage: node github-api.js <command> [args...]
 *
 * Commands:
 *   create-repo <name> [description]     Create a new repo under liquid-books
 *   delete-repo <name>                   Delete a repo (careful!)
 *   enable-pages <name>                  Enable GitHub Pages (Actions source)
 *   pages-status <name>                  Check Pages deployment status
 *   repo-info <name>                     Get repo info
 *   list-repos                           List all repos
 *   push <localPath> <repoName> [msg]    Add, commit, and push changes
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');

const TOKEN_PATH = '/home/node/.openclaw/github-token';
const OWNER = 'liquid-books';

function getToken() {
  return fs.readFileSync(TOKEN_PATH, 'utf8').trim();
}

function githubRequest(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.github.com',
      path: endpoint,
      method,
      headers: {
        'Authorization': `token ${getToken()}`,
        'User-Agent': 'openclaw-book-writer',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      }
    };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
    }

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let parsed;
        try { parsed = JSON.parse(data); } catch { parsed = data; }
        if (res.statusCode >= 400) {
          reject({ status: res.statusCode, body: parsed });
        } else {
          resolve({ status: res.statusCode, body: parsed });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

const commands = {
  async 'create-repo'(name, description = '') {
    // Create repo under the liquid-books org/user
    const res = await githubRequest('POST', '/user/repos', {
      name,
      description: description || `📚 ${name} — Built with MyST Markdown`,
      homepage: `https://${OWNER}.github.io/${name}`,
      private: false,
      auto_init: false,
      has_issues: false,
      has_wiki: false,
    });
    console.log(JSON.stringify({
      success: true,
      repo: res.body.full_name,
      html_url: res.body.html_url,
      clone_url: res.body.clone_url,
      pages_url: `https://${OWNER}.github.io/${name}`,
    }, null, 2));
  },

  async 'delete-repo'(name) {
    const res = await githubRequest('DELETE', `/repos/${OWNER}/${name}`);
    console.log(JSON.stringify({ success: true, deleted: `${OWNER}/${name}` }));
  },

  async 'enable-pages'(name) {
    // Enable GitHub Pages with Actions as the build source
    try {
      const res = await githubRequest('POST', `/repos/${OWNER}/${name}/pages`, {
        build_type: 'workflow',
      });
      console.log(JSON.stringify({
        success: true,
        pages_url: res.body.html_url || `https://${OWNER}.github.io/${name}`,
        source: 'github-actions',
      }, null, 2));
    } catch (err) {
      // Pages might already be enabled
      if (err.status === 409) {
        // Try updating instead
        const res = await githubRequest('PUT', `/repos/${OWNER}/${name}/pages`, {
          build_type: 'workflow',
        });
        console.log(JSON.stringify({
          success: true,
          pages_url: `https://${OWNER}.github.io/${name}`,
          source: 'github-actions',
          note: 'Pages already existed, updated to Actions source',
        }, null, 2));
      } else {
        throw err;
      }
    }
  },

  async 'pages-status'(name) {
    try {
      const res = await githubRequest('GET', `/repos/${OWNER}/${name}/pages`);
      console.log(JSON.stringify({
        url: res.body.html_url,
        status: res.body.status,
        build_type: res.body.build_type,
        cname: res.body.cname,
      }, null, 2));
    } catch (err) {
      if (err.status === 404) {
        console.log(JSON.stringify({ status: 'not_enabled', message: 'GitHub Pages not yet enabled' }));
      } else throw err;
    }
  },

  async 'repo-info'(name) {
    const res = await githubRequest('GET', `/repos/${OWNER}/${name}`);
    console.log(JSON.stringify({
      full_name: res.body.full_name,
      html_url: res.body.html_url,
      clone_url: res.body.clone_url,
      default_branch: res.body.default_branch,
      has_pages: res.body.has_pages,
      description: res.body.description,
      created_at: res.body.created_at,
      pushed_at: res.body.pushed_at,
    }, null, 2));
  },

  async 'list-repos'() {
    const res = await githubRequest('GET', `/users/${OWNER}/repos?per_page=100&sort=updated`);
    const repos = res.body.map(r => ({
      name: r.name,
      html_url: r.html_url,
      has_pages: r.has_pages,
      description: r.description,
      updated_at: r.updated_at,
    }));
    console.log(JSON.stringify(repos, null, 2));
  },

  async 'push'(localPath, repoName, message = 'Update book content') {
    const absPath = path.resolve(localPath);
    if (!fs.existsSync(absPath)) {
      throw new Error(`Path does not exist: ${absPath}`);
    }

    const remoteUrl = `https://${getToken()}@github.com/${OWNER}/${repoName}.git`;

    // Check if git is initialized
    const isGitRepo = fs.existsSync(path.join(absPath, '.git'));

    const run = (cmd) => {
      try {
        return execSync(cmd, { cwd: absPath, encoding: 'utf8', stdio: 'pipe' });
      } catch (err) {
        const stderr = err.stderr ? err.stderr.toString() : '';
        const stdout = err.stdout ? err.stdout.toString() : '';
        throw new Error(`Command failed: ${cmd}\nExit code: ${err.status}\nStderr: ${stderr}\nStdout: ${stdout}`);
      }
    };

    if (!isGitRepo) {
      run('git init');
      run('git branch -M main');
      run(`git remote add origin ${remoteUrl}`);
    } else {
      // Update remote URL (in case token changed)
      try { run(`git remote set-url origin ${remoteUrl}`); }
      catch { run(`git remote add origin ${remoteUrl}`); }
    }

    // Stage all changes
    run('git add -A');

    // Check if there are staged changes to commit
    let hasChanges = false;
    try {
      run('git diff --cached --quiet');
      hasChanges = false;
    } catch {
      hasChanges = true;
    }

    if (hasChanges) {
      run(`git commit -m "${message.replace(/"/g, '\\"')}"`);
    }

    // ALWAYS check if local is ahead of remote and push if needed
    let needsPush = false;
    try {
      // Fetch remote to compare
      run('git fetch origin main 2>/dev/null || true');
      const status = run('git status -sb').trim();
      needsPush = status.includes('ahead') || !status.includes('origin/main');
    } catch {
      // If fetch fails (new repo, no remote branch yet), we need to push
      needsPush = true;
    }

    if (!needsPush && !hasChanges) {
      console.log(JSON.stringify({
        success: true,
        pushed: false,
        message: 'No changes to commit and branch is up to date with remote',
        repo: `${OWNER}/${repoName}`,
      }));
      return;
    }

    if (needsPush) {
      run('git push -u origin main');
      // Verify the push actually worked by checking remote
      const localHash = run('git rev-parse HEAD').trim();
      let remoteHash = '';
      try {
        run('git fetch origin main');
        remoteHash = run('git rev-parse origin/main').trim();
      } catch {
        // If we can't fetch, at least the push didn't throw
      }

      if (remoteHash && localHash !== remoteHash) {
        throw new Error(`Push verification failed! Local HEAD: ${localHash}, Remote HEAD: ${remoteHash}`);
      }

      console.log(JSON.stringify({
        success: true,
        pushed: true,
        committed: hasChanges,
        repo: `${OWNER}/${repoName}`,
        message: hasChanges ? message : 'Pushed existing commits (no new changes staged)',
        commit: localHash,
        pages_url: `https://${OWNER}.github.io/${repoName}`,
      }, null, 2));
    } else {
      console.log(JSON.stringify({
        success: true,
        pushed: false,
        committed: hasChanges,
        message: hasChanges ? 'Committed but already in sync with remote' : 'Nothing to do',
        repo: `${OWNER}/${repoName}`,
      }));
    }
  },
};

async function main() {
  const [,, command, ...args] = process.argv;
  if (!command || !commands[command]) {
    console.log('GitHub Books API\n');
    console.log('Commands:');
    console.log('  create-repo <name> [description]');
    console.log('  delete-repo <name>');
    console.log('  enable-pages <name>');
    console.log('  pages-status <name>');
    console.log('  repo-info <name>');
    console.log('  list-repos');
    console.log('  push <localPath> <repoName> [commitMessage]');
    process.exit(1);
  }
  try {
    await commands[command](...args);
  } catch (err) {
    console.error(JSON.stringify({ error: true, message: err.message || err, details: err.body || null }, null, 2));
    process.exit(1);
  }
}

main();
